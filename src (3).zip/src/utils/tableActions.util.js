// Utility function for tableActions

export const TableActionsUtil = () => {
    // Add utility logic here
};